package com.example.testapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CloudTestApp1Application {

	public static void main(String[] args) {
		SpringApplication.run(CloudTestApp1Application.class, args);
	}

}
